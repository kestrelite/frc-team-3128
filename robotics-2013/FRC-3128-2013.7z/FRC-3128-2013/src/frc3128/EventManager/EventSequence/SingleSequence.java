package frc3128.EventManager.EventSequence;

public abstract class SingleSequence extends SequenceEvent {
    public final boolean exitConditionMet() {return true;}
}